<?php
$lang['login_login']='Iniciar Sesión';
$lang['login_username']='Usuario';
$lang['login_password']='Contraseña';
$lang['login_go']='Ir';
$lang['login_invalid_username_and_password']='Usuario/Contraseña inválidos';
$lang['login_welcome_message']='Bienvenido(a) al Sistema Open Source Point of Sale. Para continuar, inicia sesión usando tu Usuario y Contraseña.';
?>
